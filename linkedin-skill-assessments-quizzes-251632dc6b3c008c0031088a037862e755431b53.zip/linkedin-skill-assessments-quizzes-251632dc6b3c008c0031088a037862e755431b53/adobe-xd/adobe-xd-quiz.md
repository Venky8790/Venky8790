## Adobe XD

#### Q1. Where was this `Lock` icon applied?

![Q1](images/001.jpg)

- [ ] in the `Components` panel
- [x] in the `Layers` panel
- [ ] in the `Property Inspector`
- [ ] in Share mode

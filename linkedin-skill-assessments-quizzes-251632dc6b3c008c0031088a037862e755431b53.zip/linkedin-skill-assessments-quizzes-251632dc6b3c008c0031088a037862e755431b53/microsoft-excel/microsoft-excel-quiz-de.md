## Microsoft Excel

#### Q1. Welche zwei Funktionen suchen nach numerischen und nicht numerischen Zeichen in Zellen?

- [ ] ISTNUMMER und ISTALPHA
- [ ] ISTZAHL und ISTTEXT
- [ ] ISTWERT und ISTTEXT
- [ ] ISTWET und ISTNUMMER
